#include<iostream>
using namespace std;

class rectangle
{
	private:
		int l,b,a;
		
	public:
		fun1()
		{
			l=12;
			b=8;
			a=l*b;
		}
		
		fun2()
		{
			cout<<a;
		}
};

main()
{
	rectangle obj1,obj2;
	obj1.fun1();
	obj1.fun2();
}
