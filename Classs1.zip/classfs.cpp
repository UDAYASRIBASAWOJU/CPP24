#include<iostream>
using namespace std;

class fs
{
	private:
		int n1,n2,n3,i,number;
		
	public:
		fun1()
		{
			n1=0;
			n2=1;
			number=10;
			cout<<n1<<" "<<n2<<" ";
		}
		fun2()
		{
		    for(i=2;i<number;i++)
		    {
		    	n3=n1+n2;
		    	cout<<n3<<" ";
		    	n1=n2;
		    	n2=n3;
			}
		}	
};

main()
{
	fs obj1,obj2;
	obj1.fun1();
	obj1.fun2();
}
