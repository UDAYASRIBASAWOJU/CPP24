#include<iostream>
using namespace std;

class first
{
	private:
	    int x,y;	
	    int a,b;
	    
	public:
		fun2()
		{ 
		    x=5;
			y=10;
			a=9;
			cout<<y;
		}
		
}   ;

main()
{
	first obj;
	obj.fun2();
}
