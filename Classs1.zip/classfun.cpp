#include<iostream>
using namespace std;

class first
{
	private:
		int a;
		static int b;
	public:
	    fun()
		{
			a=8;
			cout<<a<<" "<<b<<" ";
			a++;
			b++;
		}
		static fun2()
		{
			cout<<b;
		}
};

int first::b=90;

main()
{
	first::fun2();
}


