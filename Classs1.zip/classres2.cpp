#include<iostream>
using namespace std;

class result
{
	private:
		float s1,s2,avg;
		
	public:
		void getdata();
		void showdata();
};

void result::getdata()
             {
             	cout<<"Enter s1:";
		    	cin>>s1;
			    cout<<"Enter s2:";
			    cin>>s2;
			 }
void result::showdata()
           	{
			avg=(s1+s2)/2;
			cout<<"Average is:"<<avg;	
	    	}
main()
{
	result obj;
	obj.getdata();
	obj.showdata();
}
