#include<iostream>
using namespace std;

class result
{
	private:
		float s1,s2,avg;
		
	public:
		fun1()
		{
			cout<<"Enter s1:";
			cin>>s1;
			cout<<"Enter s2:";
			cin>>s2;
	
		}
		fun2()
		{
			avg=(s1+s2)/2;
			cout<<"Average is:"<<avg;	
		}
};

main()
{
	result obj1,obj2;
	obj1.fun1();
	obj1.fun2();
}
