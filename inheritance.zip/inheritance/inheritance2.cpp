#include<iostream>//private
using namespace std;

class base
{	
	protected:
	    int x,y;
	public:    
	    void showb()
	    {
	    	cout<<x<<"  "<<y<<endl;
		}
};

class derived:private base
{
	private:
	protected:
		int z;
	public:
		void getd()
		{
			cout<<"Enter values of x,y,z:"<<endl;
			cin>>x>>y>>z;
		}
		void showd()
		{
			cout<<z;
			showb();
		}
};

main()
{
	derived obj;
	obj.getd();
	//obj.showb();
	obj.showd();
}
