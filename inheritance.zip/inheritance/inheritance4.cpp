#include<iostream>//hierachy inheritance
using namespace std;

class base1
{
	protected:
		int x;
	public:	
		void get1()
		{
			x=10;
		}
};

class derived1:public base1
{
	public:
		void display1()
		{
			get1();
			cout<<x<<" Accesses in derived1"<<endl;
		}
};

class derived2:public base1
{
	public:
		void display2()
		{
			get1();
			cout<<x<<" Accesses in derived2"<<endl;
		}
};

main()
{
	derived1 obj1;
	derived2 obj2;
	obj1.display1();
	obj2.display2();
}
