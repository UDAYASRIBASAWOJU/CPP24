#include<iostream>//multiple inheritance
using namespace std;

class base1
{
	protected:
		int m;
		void get1()
		{
			m=10;
		}
};

class base2
{
	protected:
		int n;
		void get2()
		{
			n=20;
		}
};

class derived:public base1,public base2
{
	public:
		show()
		{
			get1();
			get2();
			cout<<m<<" "<<n;
		}
};

main()
{
	derived obj;
	obj.show();
}
