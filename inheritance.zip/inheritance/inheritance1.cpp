#include<iostream>//public
using namespace std;

class vehicle
{
	public:
		int x;
		show()
		{
			x=9; y=10; z=1;
			cout<<x+y+z;
		}
	private:
		int y;
	protected:
		int z;
};

class truck:public vehicle
{
	public:
		int seat;
	private:
		int engine;
	protected:
		int year;
};

main()
{
	truck obj;
	obj.show();
}
