#include<iostream>
using namespace std;

main()
{
	int a=1;
	try
	{
		try
		{
			throw a;
		}
		catch(int x)
		{
			cout<<"inner catch"<<endl;
			throw  x;
		}
	}
	catch(int y)
	{
		cout<<"outer catch";
	}
}
