#include<iostream>
using namespace std;

main()
{
	int a;
	cout<<"enter your choice"<<endl;
	cin>>a;
	try
	{
		if(a==1)
		{
			throw a;
		}
		else if(a==2)
		{
			throw 'A';
		}
		else if(a==3)
		{
			throw 6.55;
		}
	}
	catch(int x)
	{
		cout<<"int type exception";
	}
	catch(char x)
	{
		cout<<"char type exception";
	}
	catch(double f)
	{
		cout<<"double type exception";
	}
	
}
