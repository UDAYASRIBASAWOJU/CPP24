#include<iostream>
using namespace std;

main()
{
		int n,d,r,w;
	    n=8;
	    d=0;
	try 
	{
	 if (d==0)
	 {
	 	throw w;
	 }
	 else
	 {
	 	r=n/d;
	 	cout<<r;
	 }
    }

catch(int x)
{
	cout<<"can't divide by zero";
}
}
