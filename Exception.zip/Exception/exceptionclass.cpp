#include<iostream>
using namespace std;

class out
{	
	public:
	    int n,d,r,w;

	    	
	    get()
	    {
	       	try 
            {
                n=8;
	            d=0;
	            if (d==0)
	            {
	 	            throw w;
	            }
	            else
                {
	            	r=n/d;
                    cout<<r;
	            }
		    }
		        catch(int x)
		        {
             	cout<<"can't divide by zero";
                }
	   	}
};

main()
{
    out obj;
    obj.get();
}
