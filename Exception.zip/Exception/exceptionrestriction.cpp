#include<iostream>
using namespace std;

void fun(int x) throw(int,char)
{
	if(x==0)
	throw 'c';
	if(x==1)
	throw 9.9;
}

main()
{
	try
	{
		fun(0);
	}
	catch(int)
	{
		cout<<"int exception";
	}
	catch(char)
	{
		cout<<"char exception";
	}
	catch(float)
	{
		cout<<"float exception";
	}
}
