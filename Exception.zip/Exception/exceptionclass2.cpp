#include<iostream>
using namespace std;

class base
{
	public:
		int n,d,r;
		void get()
		{
			cout<<n/d;
		}
};

main()
{
	int j;
	base obj;
	obj.n=4;
	obj.d=0;
	try
	{
	if(obj.d==0)
	{
		throw j;
	}
	else
	{
		obj.get();
	}
	}
	catch(int x)
	{
		cout<<"can't divide by 0";
	}
}
