#include<iostream>
using namespace std;

main()
{
	int x;
	int fun(int,int);
    //cout<<fun(7,8);
    x=fun(8,3);
    cout<<x;
}

int fun(int a,int b)
{
	int c;
	c=a+b;
	return c;
}
