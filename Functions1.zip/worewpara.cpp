#include<iostream>
using namespace std;

main()
{
	void fun(int a,int b);
	fun(5,8);
}

void fun(int p,int q)
{
	int w;
	w=p+q;
	cout<<w;
}
