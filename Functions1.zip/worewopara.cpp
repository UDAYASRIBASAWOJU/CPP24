#include<iostream>
using namespace std;

main()
{
	void fun();
	fun();
}

void fun()
{
	cout<<"hi"<<endl;
	int x=20;int y=30;
	int z;
	z=x+y;
	cout<<z;
	return;
}
