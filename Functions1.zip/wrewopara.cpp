#include<iostream>
using namespace std;

main()
{
	int fun();
    cout<<fun();
}

int fun()
{
	int a=7,b=4,c;
	c=a+b;
	//cout<<c;
	return c;
}
