#include<iostream>
using namespace std;

class base {
	public:	
	    get() {
			cout<<"I'm in base class";
		}
};

class derive:public base{
	public:	
		get() {
			cout<<"I'm in derived class";
		//	base::get();
		}
};

main()
{
	derive obj;
//	obj.get();
	obj.base::get();
}
