#include<iostream>
using namespace std;

class base1 {
	protected:
		int a;
	public:	
		void get1() {
			a=9;
		}
};

class derive1:public base1 {
	protected:
		int b;
	public:	
		void get2() {
			b=20;
		}
};

class base2 {
	protected:
		int d;
	public:	
		void get3() {
			d=12;
		}
};

class derive2:public derive1, public base2 {
	private:
		int c;
	public:
		void sum() {
			get1();
			get2();
			get3();
			c=a+b+d;
			cout<<c;
		}
};

main()
{
	derive2 obj;
	obj.sum();
}
